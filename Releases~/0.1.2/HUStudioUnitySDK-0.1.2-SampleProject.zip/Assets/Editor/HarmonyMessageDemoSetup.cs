using UnityEditor;
using UnityEditor.Events;
using UnityEngine;
using UnityEngine.UI;

public static class HarmonyMessageDemoSetup
{
    private const string PrefabPath = "Assets/Prefabs/HarmonyDemoUI.prefab";

    public static void AddMessageButton()
    {
        var root = PrefabUtility.LoadPrefabContents(PrefabPath);
        try
        {
            var panel = root.transform.Find("TestPanel");
            var probe = root.GetComponent<HarmonyDemoController>();
            if (panel == null || probe == null)
                throw new System.InvalidOperationException("HarmonyDemoUI is missing TestPanel or HarmonyDemoController");
            if (panel.Find("MessageButton") != null) return;

            var objectName = new GameObject("MessageButton", typeof(RectTransform), typeof(Image), typeof(Button));
            var rect = objectName.GetComponent<RectTransform>();
            rect.SetParent(panel, false);
            rect.anchorMin = rect.anchorMax = new Vector2(0, 1);
            rect.pivot = new Vector2(0, 1);
            rect.anchoredPosition = new Vector2(24, -665);
            rect.sizeDelta = new Vector2(260, 56);
            var background = objectName.GetComponent<Image>();
            background.color = new Color(0.25f, 0.29f, 0.34f, 1);
            var button = objectName.GetComponent<Button>();
            button.targetGraphic = background;

            var captionObject = new GameObject("Caption", typeof(RectTransform), typeof(Text));
            var captionRect = captionObject.GetComponent<RectTransform>();
            captionRect.SetParent(rect, false);
            captionRect.anchorMin = Vector2.zero;
            captionRect.anchorMax = Vector2.one;
            captionRect.offsetMin = captionRect.offsetMax = Vector2.zero;
            var caption = captionObject.GetComponent<Text>();
            caption.text = "Unity / Native";
            caption.font = Resources.Load<Font>("msyh") ?? Resources.GetBuiltinResource<Font>("Arial.ttf");
            caption.fontSize = 24;
            caption.color = Color.white;
            caption.alignment = TextAnchor.MiddleCenter;
            caption.raycastTarget = false;

            UnityEventTools.AddPersistentListener(button.onClick, probe.OnMessageClicked);
            PrefabUtility.SaveAsPrefabAsset(root, PrefabPath);
            AssetDatabase.SaveAssets();
        }
        finally
        {
            PrefabUtility.UnloadPrefabContents(root);
        }
    }

    public static void AddSoundButton()
    {
        var root = PrefabUtility.LoadPrefabContents(PrefabPath);
        try
        {
            var panel = root.transform.Find("TestPanel");
            var probe = root.GetComponent<HarmonyDemoController>();
            if (panel == null || probe == null)
                throw new System.InvalidOperationException("HarmonyDemoUI is missing TestPanel or HarmonyDemoController");
            if (root.GetComponent<AudioSource>() == null)
                root.AddComponent<AudioSource>().playOnAwake = false;
            if (panel.Find("SoundButton") != null)
            {
                PrefabUtility.SaveAsPrefabAsset(root, PrefabPath);
                return;
            }

            var objectName = new GameObject("SoundButton", typeof(RectTransform), typeof(Image), typeof(Button));
            var rect = objectName.GetComponent<RectTransform>();
            rect.SetParent(panel, false);
            rect.anchorMin = rect.anchorMax = new Vector2(0, 1);
            rect.pivot = new Vector2(0, 1);
            rect.anchoredPosition = new Vector2(310, -665);
            rect.sizeDelta = new Vector2(240, 56);
            var background = objectName.GetComponent<Image>();
            background.color = new Color(0.25f, 0.29f, 0.34f, 1);
            var button = objectName.GetComponent<Button>();
            button.targetGraphic = background;

            var captionObject = new GameObject("Caption", typeof(RectTransform), typeof(Text));
            var captionRect = captionObject.GetComponent<RectTransform>();
            captionRect.SetParent(rect, false);
            captionRect.anchorMin = Vector2.zero;
            captionRect.anchorMax = Vector2.one;
            captionRect.offsetMin = captionRect.offsetMax = Vector2.zero;
            var caption = captionObject.GetComponent<Text>();
            caption.text = "Play sound";
            caption.font = Resources.Load<Font>("msyh") ?? Resources.GetBuiltinResource<Font>("Arial.ttf");
            caption.fontSize = 24;
            caption.color = Color.white;
            caption.alignment = TextAnchor.MiddleCenter;
            caption.raycastTarget = false;

            UnityEventTools.AddPersistentListener(button.onClick, probe.OnSoundClicked);
            PrefabUtility.SaveAsPrefabAsset(root, PrefabPath);
            AssetDatabase.SaveAssets();
        }
        finally
        {
            PrefabUtility.UnloadPrefabContents(root);
        }
    }
}
