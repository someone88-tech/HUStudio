using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public static class HarmonyWebGLBuild
{
    private const string ScenePath = "Assets/Scenes/HarmonyDemoScene.unity";
    private const string PrefabPath = "Assets/Prefabs/HarmonyDemoUI.prefab";

    private static RectTransform Element(string name, Transform parent, float x, float y, float width, float height)
    {
        var gameObject = new GameObject(name, typeof(RectTransform));
        var rect = gameObject.GetComponent<RectTransform>();
        rect.SetParent(parent, false);
        rect.anchorMin = rect.anchorMax = new Vector2(0, 1);
        rect.pivot = new Vector2(0, 1);
        rect.anchoredPosition = new Vector2(x, -y);
        rect.sizeDelta = new Vector2(width, height);
        return rect;
    }

    private static Text Label(Transform parent, string name, string value, float x, float y,
        float width, float height, Font font, int size, Color color)
    {
        var rect = Element(name, parent, x, y, width, height);
        var text = rect.gameObject.AddComponent<Text>();
        text.font = font;
        text.fontSize = size;
        text.color = color;
        text.text = value;
        text.alignment = TextAnchor.MiddleLeft;
        text.raycastTarget = false;
        return text;
    }

    private static InputField Field(Transform parent, string name, string value,
        float x, float y, float width, float height, Font font)
    {
        var rect = Element(name, parent, x, y, width, height);
        var image = rect.gameObject.AddComponent<Image>();
        image.color = Color.white;
        var field = rect.gameObject.AddComponent<InputField>();
        field.targetGraphic = image;
        var textRect = Element("Text", rect, 12, 0, width - 24, height);
        var text = textRect.gameObject.AddComponent<Text>();
        text.font = font;
        text.fontSize = 27;
        text.color = Color.black;
        text.alignment = TextAnchor.MiddleLeft;
        text.supportRichText = false;
        field.textComponent = text;
        field.text = value;
        rect.gameObject.AddComponent<HarmonyKeyboardBridge>();
        return field;
    }

    private static Button Action(Transform parent, string name, string caption,
        float x, float y, float width, float height, Font font)
    {
        var rect = Element(name, parent, x, y, width, height);
        var image = rect.gameObject.AddComponent<Image>();
        image.color = new Color(0.25f, 0.29f, 0.34f, 1);
        var button = rect.gameObject.AddComponent<Button>();
        button.targetGraphic = image;
        var label = Label(rect, "Caption", caption, 0, 0, width, height,
            font, 24, Color.white);
        label.alignment = TextAnchor.MiddleCenter;
        return button;
    }

    private static GameObject CreateInterface()
    {
        var root = new GameObject("HarmonyDemoController", typeof(RectTransform), typeof(Canvas),
            typeof(CanvasScaler), typeof(GraphicRaycaster), typeof(HarmonyDemoController));
        var canvas = root.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = root.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1260, 2720);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0;
        var font = Resources.Load<Font>("msyh") ?? Resources.GetBuiltinResource<Font>("Arial.ttf");
        var panel = Element("TestPanel", root.transform, 24, 140, 1120, 740);
        var panelImage = panel.gameObject.AddComponent<Image>();
        panelImage.color = new Color(0.035f, 0.055f, 0.08f, 0.97f);
        panelImage.raycastTarget = false;
        Label(panel, "Title", "Unity for HarmonyOS NEXT Demo", 220, 8,
            840, 56, font, 30, Color.white);
        Label(panel, "HttpLabel", "HTTP URL", 24, 82, 210, 52, font, 26, Color.white);
        var http = Field(panel, "HttpUrl", "http://127.0.0.1:19333/get", 235, 82,
            855, 52, font);
        Label(panel, "WebSocketLabel", "WebSocket URL", 24, 145, 210, 52, font, 26, Color.white);
        var websocket = Field(panel, "WebSocketUrl", "ws://127.0.0.1:19333/ws", 235, 145,
            855, 52, font);
        var httpButton = Action(panel, "HttpButton", "HTTP GET/POST", 24, 220, 202, 62, font);
        var websocketButton = Action(panel, "WebSocketButton", "WebSocket", 240, 220, 202, 62, font);
        var storageButton = Action(panel, "StorageButton", "Storage", 456, 220, 202, 62, font);
        var workerButton = Action(panel, "WorkerButton", "Worker", 672, 220, 202, 62, font);
        var imeButton = Action(panel, "ImeButton", "IME", 888, 220, 202, 62, font);
        Label(panel, "TypedLabel", "Typed text", 24, 308, 210, 55, font, 26, Color.white);
        Field(panel, "TypedInput", "", 235, 308, 855, 55, font);

        var outputRect = Element("OutputScroll", panel, 24, 385, 1066, 265);
        outputRect.gameObject.AddComponent<RectMask2D>();
        var scroll = outputRect.gameObject.AddComponent<ScrollRect>();
        scroll.viewport = outputRect;
        scroll.horizontal = false;
        scroll.vertical = true;
        var content = Element("Content", outputRect, 0, 0, 1060, 900);
        scroll.content = content;
        var output = Label(content, "OutputText",
            "Tap a button to test the HarmonyOS NEXT features. HTTP/WS: hdc rport 19333.",
            0, 0, 1040, 900, font, 25, Color.white);
        output.alignment = TextAnchor.UpperLeft;
        var hideButton = Action(panel, "HideImeButton", "Hide IME", 888, 665, 202, 56, font);

        Label(root.transform, "KeyboardTestLabel", "UGUI InputField (prefab)", 40, 960,
            820, 50, font, 25, Color.white);
        var keyboard = Field(root.transform, "UGUI InputField", "abc", 40, 1020, 820, 78, font);

        var probe = root.GetComponent<HarmonyDemoController>();
        probe.Configure(http, websocket, keyboard, output);
        UnityEventTools.AddPersistentListener(httpButton.onClick, probe.OnHttpClicked);
        UnityEventTools.AddPersistentListener(websocketButton.onClick, probe.OnWebSocketClicked);
        UnityEventTools.AddPersistentListener(storageButton.onClick, probe.OnStorageClicked);
        UnityEventTools.AddPersistentListener(workerButton.onClick, probe.OnWorkerClicked);
        UnityEventTools.AddPersistentListener(imeButton.onClick, probe.OnImeClicked);
        UnityEventTools.AddPersistentListener(hideButton.onClick, probe.OnHideImeClicked);
        return root;
    }

    [MenuItem("HarmonyOS NEXT Demo/Create Test Scene")]
    public static void CreateTestScene()
    {
        Directory.CreateDirectory("Assets/Scenes");
        Directory.CreateDirectory("Assets/Prefabs");
        bool createPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath) == null;
        if (createPrefab)
        {
            var interfaceObject = CreateInterface();
            PrefabUtility.SaveAsPrefabAsset(interfaceObject, PrefabPath);
            UnityEngine.Object.DestroyImmediate(interfaceObject);
            AssetDatabase.SaveAssets();
        }
        if (createPrefab || !File.Exists(ScenePath))
        {
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            var camera = cameraObject.AddComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.05f, 0.08f, 0.12f);
            cameraObject.transform.position = new Vector3(0, 0, -10);
            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
            PrefabUtility.InstantiatePrefab(prefab, scene);
            EditorSceneManager.SaveScene(scene, ScenePath);
            Debug.Log("[UnityDemoBuild] UI prefab instance saved in scene: " + ScenePath);
        }
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
    }

    [MenuItem("HarmonyOS NEXT Demo/Build WebGL Test")]
    public static void Build()
    {
        CreateTestScene();
        HarmonyMessageDemoSetup.AddMessageButton();
        HarmonyMessageDemoSetup.AddSoundButton();
        PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled;
        PlayerSettings.WebGL.threadsSupport = false;
        PlayerSettings.WebGL.nameFilesAsHashes = false;
        PlayerSettings.productName = "out";
        string output = Path.GetFullPath(Path.Combine(Application.dataPath, "../WebGL"));
        Directory.CreateDirectory(output);
        var options = new BuildPlayerOptions {
            scenes = new[] { ScenePath },
            locationPathName = output,
            target = BuildTarget.WebGL,
            options = BuildOptions.None
        };
        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result != BuildResult.Succeeded)
            throw new Exception("Unity WebGL build failed: " + report.summary.result);
        string buildDir = Path.Combine(output, "Build");
        string[] loaders = Directory.GetFiles(buildDir, "*.loader.js");
        if (loaders.Length == 0) throw new Exception("Unity WebGL loader missing");
        string loader = Array.Find(loaders, path => Path.GetFileName(path) != "out.loader.js") ?? loaders[0];
        string stem = Path.GetFileName(loader).Replace(".loader.js", "");
        if (stem != "out")
            foreach (string suffix in new[] { ".loader.js", ".framework.js", ".data", ".wasm" })
                File.Copy(Path.Combine(buildDir, stem + suffix),
                          Path.Combine(buildDir, "out" + suffix), true);
        File.Copy(Path.Combine(Application.dataPath, "../main.template.js"),
                  Path.Combine(output, "main.js"), true);
        Debug.Log("[UnityDemoBuild] WebGL output: " + output);
    }
}
